/* eslint-disable prettier/prettier */
import React, {Component} from 'react';
import {Text,View,StyleSheet,TouchableOpacity,Image} from 'react-native';
// import Icon from 'react-native-vector-icons/FontAwesome';
import PrimaryButton from '../components/PrimaryButton';
import {colors} from '../config/Colors';

export class InitialLaunchScreen extends Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.languageWrapper}>
          <TouchableOpacity>
            <Text style={styles.language}>
              <Text>English (United States) </Text>
              {/* <Icon name="angle-down" size={25} color={colors.gray1}/> */}
            </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.buttonWrapper}>
          <Image
            style={styles.instaLogo}
            source={require('../assets/images/ggg.png')}
          />
            <PrimaryButton
              buttonBgColor={colors.green}
              textColor={colors.secondary}
              buttonLabel={'Create New Account'}
            />
          </View>
            <PrimaryButton
              buttonBgColor={colors.green}
              textColor={colors.secondary}
              buttonLabel={'Login'}
            />
        <View style={styles.footerWrapper}>
          <View style={styles.footerContentWrapper}>
            {/* <Text style={styles.from}>from</Text> */}
            <Text style={styles.facebook}>we deliver excellence</Text>
          </View>
        </View>
        </View>
    );
  }
}

export default InitialLaunchScreen;

export const styles = StyleSheet.create({
  container: {
    display: 'flex',
    flex: 1,
    justifyContent: 'center',
  },
  languageWrapper: {
    display: 'flex',
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  buttonsWrapper: {
    display: 'flex',
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerWrapper: {
    display: 'flex',
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  language:{
    color:colors.gray1,
  },
  instaLogo: {
    alignSelf: 'center',
    width: '50%',
    height: '25%',
  },
  footerContentWrapper: {
    borderTopColor: colors.gray1,
    borderTopWidth:1,
    width:'100%',
    alignItems:'center',
    padding:10,
  },

  from: {
    textAlign: 'center',
    color: colors.gray1,
  },
  facebook: {
    textAlign: 'center',
    fontWeight: 'bold',
  },
});
