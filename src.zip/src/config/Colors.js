/* eslint-disable prettier/prettier */
export const colors = {
  primary: '#3897f0',
  secondary: '#ffff',
  gray: 'gray',
  gray1: '#E8E8E8',
  black: 'black',
  primaryBlue: '#009cff',
  blue: 'blue',
  green : 'green',
};
